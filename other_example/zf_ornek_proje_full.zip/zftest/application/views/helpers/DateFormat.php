<?php
class Zend_View_Helper_DateFormat {
    public function DateFormat($date, $format = '')
    {
        switch ($format) {
            case 'datetime':
                $format = "dd MMMM yyyy, HH:mm";
                break;

            case 'date':
                $format = "dd MMMM yyyy EEEE";
                break;

            case 'timeLeft':
                return $this->timeLeft($date);
                break;

        	default:
        	    if(!$format)
            		$format = "dd MMMM yyyy EEEE";
        }

        $locale = new Zend_Locale('tr_TR');
        $date = new Zend_Date($date, false, $locale);
        return $date->toString($format);
    }

    private function timeLeft($date)
    {
		list($t,$s) = explode(' ',$date);
		$tt = explode('-',$t);
		$ss = explode(':',$s);

		$time = mktime($ss[0],$ss[1],$ss[2],$tt[1],$tt[2],$tt[0]);

		$delta = time() - $time;

		if(date("Y",$time) != date("Y")) {
			return date("d.m.Y H:i",$time).' tarihinde';
		}


        if($delta < 0)
            $delta = $delta + 93;

		$tarih = $delta." sn. önce";

		if($delta > 59) {
			$dakika = floor($delta/60);
			if(!$dakika) $dakika = 1;
			$saniye = $delta%60;
			$tarih = $dakika." dk. önce";
			if($dakika > 59) {
				$saat = floor($dakika/60);
				if(!$saat) $saat = 1;
				$dakika = $dakika%60;
				$tarih = $saat." saat önce";
				if($saat > 23) {
					$gun = floor($saat/24);
					if(!$gun) $gun = 1;
					$saat = $saat%24;
					$tarih = $gun." gün önce";
					if($gun > 6) {
						$hafta = floor($gun/7);
						if(!$hafta) $hafta = 1;
						$gun = $gun%7;
						$tarih = $hafta." hafta önce";
						if($hafta > 3) {
							$ay2 = floor($hafta/4);
							if(!$ay2) $ay2 = 1;
							$hafta = $hafta%4;
							$tarih = $ay2." ay önce";
						}
					}
				}
			}
		}
		return $tarih;
    }
}