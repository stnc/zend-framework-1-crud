<?php
/**
 * Model veriye erişimizdeki arabirimlerdir.
 * Bu class'ı web arabiriminde de kullanabilirsiniz, bir API
 * yazmak istediğinizde de kullanabilirsiniz.
 *
 * Kaydedilen data'nın doğruluğu vs. burada kontrol edilmelidir.
 *
 * Zend Framework ile ilgili dokümanlarda Zend_Db_Table altyapısı kullanılmaktadır
 * ancak kişisel olarak çok kullanışsız bulduğum için Zend_Db_Table ile
 * örnek vermedim. İnternet'teki diğer dokümanlara bakarak Zend_Db_Table uyarlaması
 * yapabilirsiniz.
 */
class Phone {
    public function __construct()
    {
        $this->db = $GLOBALS['db'];
    }

    public function insert($data)
    {
        if(!$data or !array($data)) {
            // Bu tarz kontrollerde önceki sayfaya dönme işi
            // controller'da yapılır ancak mantık olarak
            // kontrollerin model'da yapılması lazım.
            die('Eksik data');
        }

        // $data'daki değerlerin veritabanıyla tuttuğundan emin olalım.
        // Bunu yapmanın mutlaka daha usturuplu yolu vardır ama o da size kalsın.
        $fields = array('name', 'surname', 'email', 'phone');

        foreach($data as $key => $val) {
            if(!in_array($key, $fields)) {
                unset($data[$key]);
            }
        }

        $data['updated'] = date("Y-m-d H:i:s");

        // DİKKAT: Ayrıca email kontrolü, boş olmaması gereken fieldlar falan da
        // kontrol edilmeli.

        $this->db->insert('phone_directory', $data);
    }

    public function update($data, $id)
    {
        if(!$data or !array($data) or !$id) {
            die('Eksik data');
        }

        $fields = array('name', 'surname', 'email', 'phone');

        foreach($data as $key => $val) {
            if(!in_array($key, $fields)) {
                unset($data[$key]);
            }
        }

        $data['updated'] = date("Y-m-d H:i:s");

        $this->db->update('phone_directory', $data, $this->db->quoteInto('id=?', $id));
    }

    public function delete($id)
    {
        $this->db->delete('phone_directory', $this->db->quoteInto('id = ?', $id));
    }

    public function getPerson($id)
    {
        // Aslında bu işlem için kullanışlı olmamakla beraber
        // Zend_Db_Select kullanım örneği olsun diye kullandım.
        // Normalde doğrudan sql cümlesini de yazabilirsiniz.
        $select = $this->db->select();
        $select->from('phone_directory');

        // Sadece name ve surname çekilecekse:
        // $select->from('phone_directory', array('name', 'surname'));

        // Bir kontrole bağlı query geliştirilebilir
        // if($condition) {
        //    $select->joinLeft('companies', 'phone_directory.company_id=companies.id', 'companies.company');
        // }

        $select->where('phone_directory.id=?', $id); // $id otomatik olarak escape edilir (bind edildiği için)

        $person = $this->db->fetchRow($select);  // $select normal bir sql cümlesi de olabilir

        if(!$person)
            return false;
        else
            return $person;
    }

    public function getEveryone()
    {
        $sql = "select * from phone_directory order by name, surname";
        $people = $this->db->fetchAll($sql);

        return $people;
    }
}
