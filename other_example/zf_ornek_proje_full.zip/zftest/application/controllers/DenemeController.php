<?php
class DenemeController extends DefaultController
{
    public function init()
    {
        parent::init();
    }

    public function indexAction()
    {
        $this->view->pageTitle = "Deneme Controller'ı Index Action'ı";
    }

    public function birAction()
    {
        $this->view->pageTitle = "Deneme 1";
    }

    public function ikiAction()
    {
        $this->_helper->viewRenderer->setNoRender();
        $this->view->pageTitle = "Deneme 2";
        $this->render('bir');
    }

}

