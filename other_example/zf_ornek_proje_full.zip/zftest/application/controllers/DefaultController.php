<?php
/**
 * Tüm controller için ortak olan işlemleri yapmak için
 * Bu Controller kullanılır.
 */
class DefaultController extends Zend_Controller_Action
{
    public function init()
    {
        $this->view->baseUrl = $this->_request->getBaseUrl();
        $this->view->currentController = $this->_request->getControllerName();

        $this->view->flash = implode('<br>', $this->_helper->FlashMessenger->getMessages());
    }

    /**
     * Basit Authentication kontrolü örneği için preDispatch metodundan yararlanıyoruz.
     * Farklı amaçlar için farklı metotlar da mevcut. Bkz:
     * - init()
     * - preDispatch()
     * - postDispatch()
     *
     */
    /*
    public function preDispatch() {
        $controller = $this->_request->getControllerName();
        if ('auth' != $controller) {
            if(!$_SESSION['id']) {
                $this->_redirect('auth/login');
            }
        }
    }
    */
}