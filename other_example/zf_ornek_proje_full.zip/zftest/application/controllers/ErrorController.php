<?php
class ErrorController extends DefaultController
{
    public function init()
    {
        parent::init();
    }

    public function errorAction()
    {
        $errors = $this->_getParam('error_handler');

        switch ($errors->type) {
            case Zend_Controller_Plugin_ErrorHandler::EXCEPTION_NO_CONTROLLER:
            case Zend_Controller_Plugin_ErrorHandler::EXCEPTION_NO_ACTION:
                // 404 header'ı gönderelim: controller ya da action bulunamadı
                $this->getResponse()->setRawHeader('HTTP/1.1 404 Not Found');

                $this->view->title = "Sayfa bulunamadı";
                $this->view->pageTitle = "Sayfa bulunamadı";
                break;

            default:
                // Diğer tüm exceptionlar için şekillendirerek hatayı ekrana bas.
                // DİKKAT: Bunu dışarıya açık projelerde bu şekilde sunmak güvenlik açığıdır.
                //         Onun yerine basit bir hata mesajı ile geçiştirip loglamak daha mantıklı
                $exception = $errors->exception;

                $this->view->title = "Hata oluştu";
                $this->view->pageTitle = $exception->getMessage();
                $this->view->errorTrace = $exception->getTraceAsString();
        }
    }
}
