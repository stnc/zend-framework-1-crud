<?php
/**
 * ZF ile verilen örneklerde IndexContoller extends Zend_Controller_Action
 * şeklinde kullanılır. Ancak tüm controller'lar için ortak işlemleri toplamak
 * için DefaultController diye bir dosya kullanmayı tercih ettim.
 *
 * parent::init() kısmını unutmamak lazım.
 */
class IndexController extends DefaultController
{
    public function init()
    {
        parent::init();

        $this->view->mainMenu = array(
            'Deneme Controller\'ı' => array('controller' => 'deneme'),
            'Deneme 3 (Olmayan Action)' => array('controller' => 'deneme', 'action' => 'uc')
        );
    }

    public function indexAction()
    {
        // Model'imizi include edelim
        // Otomatik olarak application/models/Phone.php'yi bulur
        $phone = new Phone();

        // Template'a göndereceğimiz datalar:
        $this->view->people = $phone->getEveryone();
        $this->view->pageTitle = "Anasayfa";


        // Metot işini bitirdikten sonra dispatcher otomatik olarak
        // application/views/index/index.phtml dosyasını bulur ve render eder.
        // Buradaki ilk index: controller, ikinci index ise action'dır.
    }

    public function newAction()
    {
        // application/views/index/new.phtml dosyasını otomatik olarak
        // render etmesini istemiyorum. Bkz. metot sonundaki render satırı
        $this->_helper->viewRenderer->setNoRender();

        $this->view->pageTitle = "Yeni Kayıt Ekle";

        // $this->url'ye gidecek parametre
        $this->view->formAction = array('action' => 'insert');


        // Default olan new.phtml yerine edit.phtml'i render etmek istiyorum
        $this->render('edit');
    }

    public function editAction()
    {
        $phone = new Phone();

        $id = $this->_request->getParam('id');

        $this->view->data = $phone->getPerson($id);

        $this->view->pageTitle = "Kayıt Güncelle";

        // $this->url'nin garip bir durumu vardır, zaten var olan parametreleri
        // kendi otomatik ekler. Dolayısıyla id parametresi ve controller otomatik
        // olarak form'un action'ına eklenir.
        $this->view->formAction = array('action' => 'update');
    }

    public function insertAction()
    {
        // Model'imizi include edelim
        // Otomatik olarak application/models/Phone.php'yi bulur
        $phone = new Phone();

        // $_POST, $_SESSION, $_GET gibi hiçbir değere doğrudan
        // erişmiyoruz. Hepsini encapsulate eden güvenli metotlar var.
        // Tüm post edilen değerleri model'a gönderelim bakalım.
        $data = $this->_request->getPost();    // = $_POST

        $phone->insert($data);


        // Session kullanılarak bir sefere mahsus mesaj gösterme olayı.
        // Tabii burada başarıyla kaydedilip kaydedilmediği ile ilgili kontrol de olmalı.
        $this->_helper->FlashMessenger('Kayıt eklendi.');


        // Post metoduyla kaydettiğimiz için kayıttan sonra refresh'e
        // basıldığında gıcık "Bu datayı tekrar post etmek istiyor musunuz"
        // sorusundan kurtulmak ve refresh'e tıklanarak mükerrer kayıt yapılmasını
        // Engellemek için HTTP ile redirect ediyoruz.
        //
        // Default ana sayfaya gönderelim. (index/index ile aynı)
        $this->_redirect('');
    }

    public function updateAction()
    {
        $phone = new Phone();

        $data = $this->_request->getPost();
        $id = $this->_request->getParam('id');

        $phone->update($data, $id);
        $this->_helper->FlashMessenger('Kayıt güncellendi.');
        $this->_redirect('');
    }

    public function deleteAction()
    {
        $phone = new Phone();

        $id = $this->_request->getParam('id');

        $phone->delete($id);

        $this->_helper->FlashMessenger('Kayıt silindi.');
        $this->_redirect('');
    }
}

