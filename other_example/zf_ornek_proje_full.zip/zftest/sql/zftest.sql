CREATE DATABASE `zftest` /*!40100 DEFAULT CHARACTER SET utf8 */;

CREATE TABLE  `zftest`.`phone_directory` (
  `id` int(10) unsigned NOT NULL auto_increment,
  `name` varchar(45) default NULL,
  `surname` varchar(45) default NULL,
  `email` varchar(95) default NULL,
  `phone` varchar(45) default NULL,
  `updated` datetime NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=9 DEFAULT CHARSET=utf8;