<?php
// Zend Framework'ü ve modellerimizi path'e dahil edelim.
set_include_path( //'.' . PATH_SEPARATOR .
                  '../lib' . PATH_SEPARATOR .
                  '../application/models/' . PATH_SEPARATOR .
                  get_include_path());


require_once "Zend/Loader.php";

// PHP5'in autoload özelliğini kullanarak ZF dosya yapısına
// göre gerekli dosyanın otomatik olarak include edilmesi için:
Zend_Loader::registerAutoload();


// registerAutoload() yapmasaydık kullandığımız paketleri tek tek
// bu şekilde include etmemiz gerekirdi:
//Zend_Loader::loadClass('Zend_Config_Ini');
//Zend_Loader::loadClass('Zend_Db');


// Konfigürasyondaki [general] kısmını oku
$config = new Zend_Config_Ini('../application/config.ini', 'general');


// Veritabanı bağlantısı kuralım.
$db = Zend_Db::factory($config->db->adapter, $config->db->config->toArray());


// MySQL'e özgü:
$db->query("SET NAMES 'utf8'");


// Front Controller'ı çağıralım, yoksa oluşturur (singleton pattern)
$frontier = Zend_Controller_Front::getInstance();


// Exception throw etmek yerine formatlı hata mesajları göstermek için false yapalım.
// Debug ederken true, yayına alırken false yapmak iyi bir fikir olabilir.
// Bkz. application/controllers/ErrorController.php
$frontier->throwExceptions(false);


// Controller'larımızı nerede arasın?
$frontier->setControllerDirectory('../application/controllers');


// Controller ve action'ın bulunması, model'ların çağırılması, view'ın render etmesi
// gibi tüm işlemleri yapar:
$frontier->dispatch();



/**************************************************************************
 * NOTLAR:
 *
 * Default route'a göre url formatı:
 * http://localhost/proje/controller/action/param_adi/param
 *
 * yani örnek verirsek:
 * http://localhost/proje/admin/logs/user_id/15/city/ankara
 *
 * baseUrl    : /proje
 * controller : admin (application/controllers/AdminController.php)
 * action     : logs (AdminController.php içindeki logsAction metodu)
 * parameter  : user_id=15, city=ankara
 *              Zend_Controller_Action::_request->getParam('user_id') ve
 *              Zend_Controller_Action::_request->getParam('city')  ile erişilir.
 *
 *
 * Yani http://localhost/proje/foo/bar adresine girdiğinizde:
 * application/controllers/FooController.php dosyasındaki barAction function'ı (metodu) çalıştırılır,
 * views/scripts/foo/bar.phtml dosyası gösterilir.
 *
 * * * * *
 *
 * Default Controller : IndexController
 * Default Action     : indexAction
 *
 * * * * *
 *
 * Class adları dosya adlarına değiştirilirken değiştirilir.
 * Ör: denemeAction için view dosyasının adı deneme.phtml iken
 *     camelCaseAction için camel-case.phtml olur.
 */