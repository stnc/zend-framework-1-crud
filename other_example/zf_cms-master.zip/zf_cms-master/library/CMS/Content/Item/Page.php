<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of Page
 *
 * @author marcin
 */
class My_CMS_Content_Item_Page extends My_CMS_Content_Item_Abstract {

    //put your code here
    public $id;
    public $name;
    public $headline;
    public $image;
    public $description;
    public $content;
}

?>
