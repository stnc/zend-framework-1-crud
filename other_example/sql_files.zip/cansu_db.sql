/*
Navicat MySQL Data Transfer

Source Server         : lo
Source Server Version : 50505
Source Host           : 127.0.0.1:3306
Source Database       : cansu_db

Target Server Type    : MYSQL
Target Server Version : 50505
File Encoding         : 65001

Date: 2017-05-05 15:28:33
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for labs
-- ----------------------------
DROP TABLE IF EXISTS `labs`;
CREATE TABLE `labs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` datetime DEFAULT NULL,
  `dataname` varchar(255) DEFAULT NULL,
  `explanation` text,
  `filename` varchar(255) DEFAULT NULL,
  `category` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=79 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of labs
-- ----------------------------
INSERT INTO `labs` VALUES ('16', '2015-02-06 00:00:00', 'wst1', 'Doxorubicin loaded DNA origami-AuNPs ve dox yüklü olmayan OrigamiC-AuNPs toksisitesine bakıldı.', '06,02,2015.xlsx', '1');
INSERT INTO `labs` VALUES ('17', '2015-02-13 00:00:00', 'wst1', 'Doxorubicin loaded DNA origami-AuNPs ve free dox toksisitesine bakıldı.', '13022015.xlsx', '1');
INSERT INTO `labs` VALUES ('18', '2015-02-06 00:00:00', 'Fluorescence spectroscopy', 'Doxorubicin loaded DNA origami-AuNPs, dox loaded DNA origami ve free dox intracellular uptake bakıldı. (Hücreler patlatılarak)', 'AuNP-dox intra 06022015.xlsx', '1');
INSERT INTO `labs` VALUES ('19', '2015-02-06 00:00:00', 'AFM', 'Freshly cut mica üzerine DNA origami damlatıldı vekurumaya bırakıldı. Ardından dH2O ile yıkanarak AFM imageleri alındı.', 'Resim1.jpg', '1');
INSERT INTO `labs` VALUES ('20', '2015-01-30 00:00:00', 'confocal', 'Doxorubicin loaded DNA origami-AuNPs hücrelerle 2 saat incube edilerek confocal imageleri alındı.', 'altin 20x.tif', '1');
INSERT INTO `labs` VALUES ('21', '2015-01-30 00:00:00', 'confocal', 'Free Dox hücrelerle 2 saat incube edilerek confocal imageleri alındı.', 'dox 20x red.tif', '1');
INSERT INTO `labs` VALUES ('22', '2015-01-30 00:00:00', 'confocal', 'Dox loaded DNA origami hücrelerle 2 saat incube edilerek confocal imageleri alındı.', 'ori 20x.tif', '1');
INSERT INTO `labs` VALUES ('23', '2015-02-13 00:00:00', 'confocal', 'Only DNA origami-AuNPs ile incube edilen hücrelerin confocal imageleri alındı.', 'au.tif', '2');
INSERT INTO `labs` VALUES ('28', '2013-02-09 00:00:00', '', 'weekly report 1', 'Cansu Ümran TAŞ 09.02.2013.docx', '2');
INSERT INTO `labs` VALUES ('29', '2015-03-27 00:00:00', 'Flow cytometry', 'doxorubicin loaded origami, origami-AuNPs, and free doxorubicin treated cells were analysed by flow cytometry and transfection ratios were found as 97, 97, and 89 percent. !! GOOD DATA FOR PROPOSAL', 'AUNPS FLOW1.docx', '1');
INSERT INTO `labs` VALUES ('30', '2015-04-30 00:00:00', 'flow', 'hela ve bt-474 hücreleri ile intracellular uptake denemesi yapıldı 40 uM stoktan her bir well için 150 uL dox yüklü sample eklendi.\r\nBT-474 hücreleri ve hela hücreleri 24 well platelere en az %90 confluency olacak şekilde (200 uL) ekildi. dox yüklü samplelar ile 3 saat inkübe edildi.', 'FLOW 300415.docx', '1');
INSERT INTO `labs` VALUES ('31', '2015-04-30 00:00:00', 'fluorescence spektroskopisi', 'hela ve bt-474 hücreleri ile intracellular uptake denemesi yapıldı 40 uM stoktan her bir well için 150 uL dox yüklü sample eklendi.\r\nBT-474 hücreleri ve hela hücreleri 24 well platelere en az %90 confluency olacak şekilde (200 uL) ekildi. dox yüklü samplelar ile 3 saat inkübe edildi.', 'bt hela30042015.xlsx', '1');
INSERT INTO `labs` VALUES ('32', '2015-06-12 00:00:00', 'DLS-AuNP modification', 'The DLS results of 8nm bare AuNPs, oligonucleotide covered AuNPs and DNA tile-AuNPs ', 'AuNPs size 12,06,2015.xls', '1');
INSERT INTO `labs` VALUES ('33', '2015-06-19 00:00:00', 'toxicity', 'dok yüklü dna tile- auNPs toxicity testi', '19062015 aunps.xlsx', '1');
INSERT INTO `labs` VALUES ('34', '2015-04-21 00:00:00', 'fluorescence spectroscopy', 'İnracellular uptake test', 'AuNP 3.tekrar.xlsx', '1');
INSERT INTO `labs` VALUES ('35', '2015-05-29 00:00:00', 'DLS', 'Okan Tez öğrencisi için altın ve gümüş nanopartiküllerin boyut analizi (50 nm)', 'cns dls.xls', '1');
INSERT INTO `labs` VALUES ('36', '2015-06-08 00:00:00', 'toxicity-lactose', 'BT ve HEla hücrelerinde laktozlu origamilerin toksisites testi', 'bt-wst1-lactose05062015.xlsx', '1');
INSERT INTO `labs` VALUES ('37', '2015-07-10 00:00:00', 'DLS', '13 nm AuNPs', 'AuNPs DLS bare.xlsx', '1');
INSERT INTO `labs` VALUES ('38', '2015-07-10 00:00:00', 'DLS', 'Oligo coated AuNPs (good one)', 'AuNPs DLS oligo coated.xlsx', '1');
INSERT INTO `labs` VALUES ('41', '2015-07-09 00:00:00', 'Fluorescence spect.', 'effect of gold nanoparticles on the doxorubicin fluorescence intensities.', 'dox au fluorescence kontrol.xlsx', '1');
INSERT INTO `labs` VALUES ('42', '2015-07-10 00:00:00', 'Fluorescence spect.', 'Intracellular uptake of folic acid modified doxorubicin loaded DNA tiles in HeLa ( first trial)', 'hela10072015.xlsx', '1');
INSERT INTO `labs` VALUES ('43', '2015-07-15 00:00:00', 'UV-std', '', 'dox std UV.xlsx', '1');
INSERT INTO `labs` VALUES ('44', '2015-07-25 00:00:00', 'Raman', 'DNA tile- AuNPs nanoyapılarının SERS aktivitesi olup olmadığına bakıldı. meğersem SERS aktivitesi yokmuş.', '240715_data.xlsx', '1');
INSERT INTO `labs` VALUES ('45', '2015-07-25 00:00:00', 'Fluorescence spect', 'DNA tile-AuNPs dox yüklendi sağlıklı ve kanser hücreleri ile co-culture sonucunda kanserli hücrelere daha çok alındığı saptandı. NET', 'au np coculture230715.xlsx', '1');
INSERT INTO `labs` VALUES ('46', '2015-11-27 00:00:00', 'DLS', '13 nm bare AuNPs, oligonucleotide ile salt aging metodu kullanılarak modifiye edilmiş AuNPs ve DNA tile-AuNPs yapılarının DLS sonuçları. 40 uL origamiye 40 uL AuNPs-oligo karıştırılarak 24 saat inkübe edildi. Herbir ölçüm 6 kez tekrarlandı.', '27.11.2015 DLS (DNA tile-AuNPs).xlsx', '1');
INSERT INTO `labs` VALUES ('47', '2015-11-27 00:00:00', 'UV', '13 nm bare AuNPs, oligonucleotide ile salt aging metodu kullanılarak modifiye edilmiş AuNPs ve DNA tile-AuNPs yapılarının UV spektrumları. 300 ve 800 nm arası scan yapıldı.', '27.11.2015 DNA tile-AuNPs UV.xlsx', '1');
INSERT INTO `labs` VALUES ('48', '2015-12-18 00:00:00', 'AFM', 'AFM of highly diluted (10 times) origamis.\r\nThe particles sizes were about 60 nm.', 'P_20151218_170718.jpg', '1');
INSERT INTO `labs` VALUES ('49', '2015-12-18 00:00:00', 'AFM', 'AFM of highly diluted (10 times) origamis.\r\nThe particles sizes were about 60 nm.', '19.12.2015_1.png', '1');
INSERT INTO `labs` VALUES ('50', '2015-12-18 00:00:00', 'AFM', 'AFM of highly diluted (10 times) origamis.\r\nThe particles sizes were about 60 nm.', '19.12.2015_2.png', '1');
INSERT INTO `labs` VALUES ('51', '2015-12-18 00:00:00', 'AFM', 'AFM of highly diluted (10 times) origamis.\r\nThe particles sizes were about 60 nm.', '19.12.2015_3.png', '1');
INSERT INTO `labs` VALUES ('52', '2015-12-18 00:00:00', 'AFM', 'AFM of highly diluted (10 times) origamis.\r\nThe particles sizes were about 60 nm.', 'P_20151219_174837_1.jpg', '1');
INSERT INTO `labs` VALUES ('53', '2015-12-18 00:00:00', 'Agarose gel electrophoresis', 'gel electrophoresis of 1,2,3,4,5,6,7,8,9 oligos respectively. 2 % agarose 80 V 60 min.', 'gel.png', '1');
INSERT INTO `labs` VALUES ('54', '2015-12-21 00:00:00', 'Formation of Orgiamis', '9 tane sample hazırlanarak origami oyuldı (1 oligodan 9 oligoya kadar) 1 numarada 25 bp (P8) var. sadece 9. sample da 140 base scafold var. Agarose gel image', '21.12.2015.tif', '1');
INSERT INTO `labs` VALUES ('55', '2015-12-21 00:00:00', 'Formation of Orgiamis', '9 tane sample hazırlanarak origami oyuldı (1 oligodan 9 oligoya kadar) 1 numarada 25 bp (P8) var. sadece 9. sample da 140 base scafold var. Agarose gel image. Siyah format.', '21.12.2015_2.tif', '1');
INSERT INTO `labs` VALUES ('56', '2015-12-23 00:00:00', 'Formation of Orgiamis', '9 tane sample hazırlanarak origami oyuldı (1 oligodan 9 oligoya kadar) 1 numarada 140 bp . Agarose gel image.', '23.12.2015 1-9 sample origami (140).tif', '1');
INSERT INTO `labs` VALUES ('57', '2015-12-23 00:00:00', 'Formation of Orgiamis', '9 tane sample hazırlanarak origami oyuldı (1 oligodan 9 oligoya kadar) 1 numarada 140 bp . Agarose gel image. siyah format', '23.12.2015 1-9 sample origami (140)_2.tif', '1');
INSERT INTO `labs` VALUES ('58', '2015-12-25 00:00:00', 'Stability of DNA origami-AuNPs', 'DNA origami AuNps hazırlanıp 2,4,6,8,12,24,48 saatlik stabilitelerine bakıldı. In PBS at room temperature.', '25.12.2015 Stability in PBS ph 7_2.tif', '1');
INSERT INTO `labs` VALUES ('59', '2015-12-25 00:00:00', 'Stability of DNA origami-AuNPs', 'DNA origami AuNps hazırlanıp 2,4,6,8,12,24,48 saatlik stabilitelerine bakıldı. In PBS at room temperature. (1)', '25.12.2015_Stability in PBS ph 7.tif', '1');
INSERT INTO `labs` VALUES ('60', '2015-12-25 00:00:00', 'Stability of DNA origami-AuNPs', 'DNA origami AuNps hazırlanıp 2,4,6,8,12,24,48 saatlik stabilitelerine bakıldı. In PBS at room temperature. (2)', '25.12.2015 stability_3.tif', '1');
INSERT INTO `labs` VALUES ('61', '2015-12-19 00:00:00', 'AFM', 'AFM images. Origamis highly diluted about 10 times and added onto mica. 1', '19.12.2015_1.png', '1');
INSERT INTO `labs` VALUES ('62', '2015-12-19 00:00:00', 'AFM', 'AFM images. Origamis highly diluted about 10 times and added onto mica. 2', '19.12.2015_2.png', '1');
INSERT INTO `labs` VALUES ('63', '2015-12-19 00:00:00', 'AFM', 'AFM images. Origamis highly diluted about 10 times and added onto mica. 3', '19.12.2015_3.png', '1');
INSERT INTO `labs` VALUES ('64', '2015-12-26 00:00:00', 'AFM', 'AFM images. Origamis highly diluted about 10 times and added onto mica. Hafta sonu alındı.\r\n1', '26.12.2015_1.png', '1');
INSERT INTO `labs` VALUES ('65', '2015-12-26 00:00:00', 'AFM', 'AFM images. Origamis highly diluted about 10 times and added onto mica. Hafta sonu alındı.\r\n2', '26.12.2015_2.png', '1');
INSERT INTO `labs` VALUES ('66', '2015-12-26 00:00:00', 'AFM', 'AFM images. Origamis highly diluted about 10 times and added onto mica. Hafta sonu alındı.\r\n3', '26.12.2015_3.png', '1');
INSERT INTO `labs` VALUES ('67', '2015-12-26 00:00:00', 'AFM', 'AFM images. Origamis highly diluted about 10 times and added onto mica. Hafta sonu alındı.\r\n4', '26.12.2015_4.png', '1');
INSERT INTO `labs` VALUES ('68', '2015-12-26 00:00:00', 'AFM', 'AFM images. Origamis highly diluted about 10 times and added onto mica. Hafta sonu alındı.\r\n5', '26.12.2015_5.png', '1');
INSERT INTO `labs` VALUES ('69', '2015-12-26 00:00:00', 'AFM', 'AFM images. Origamis highly diluted about 10 times and added onto mica. Hafta sonu alındı.\r\n6', '26.12.2015_6.png', '1');
INSERT INTO `labs` VALUES ('70', '2015-12-26 00:00:00', 'AFM', 'AFM images. Origamis highly diluted about 10 times and added onto mica. Hafta sonu alındı.\r\n\r\nsoftware image almayı tamamlayıp processn etmeden önce screen shot alındı\r\n1', 'screen shot2 26.12.2015.PNG', '1');
INSERT INTO `labs` VALUES ('71', '2015-12-26 00:00:00', 'AFM', 'AFM images. Origamis highly diluted about 10 times and added onto mica. Hafta sonu alındı.\r\n\r\nsoftware image almayı tamamlayıp processn etmeden önce screen shot alındı\r\n2', 'screen shot3 26.12.2015.PNG', '1');
INSERT INTO `labs` VALUES ('72', '2015-12-26 00:00:00', 'AFM', 'AFM images. Origamis highly diluted about 10 times and added onto mica. Hafta sonu alındı.\r\n\r\nsoftware image almayı tamamlayıp processn etmeden önce screen shot alındı\r\n3', 'screen shot4 26.12.2015.PNG', '1');
INSERT INTO `labs` VALUES ('73', '2016-03-15 00:00:00', 'Apoptosis', 'bad data', 'bt.pdf', '1');
INSERT INTO `labs` VALUES ('74', '2016-03-15 00:00:00', 'Cell cycle analysis', 'control hücrelerinin gating ve oranları', 'cell cycle bt control.pdf', '1');
INSERT INTO `labs` VALUES ('75', '2016-03-15 00:00:00', 'Cell cycle analysis', 'test hücrelerinin cell cycle phase distributionu idare eder.', 'cell cycle bt_1ug_2.pdf', '1');
INSERT INTO `labs` VALUES ('76', '2016-03-01 00:00:00', 'toxicity of Orgi-Morph', 'HER2 morpholino embedded DNA tile ların toksisiteleri. Hücreler 1, 2, 4, 8 ug origami ile muamele edilip (FBS free media içinde) 4 saat sonra FBS li DMEM eklendi ve 72 saat sonra toksisitesi belirlendi.', 'cansu-bt-72h-05.03.2016.xlsx', '1');
INSERT INTO `labs` VALUES ('77', '2016-03-01 00:00:00', 'toxicity of Orgi-Morph 24 saat', 'HER2 morpholino embedded DNA tile ların toksisiteleri. Hücreler 1, 2, 4, 8 ug origami ile muamele edilip (FBS free media içinde) 4 saat sonra FBS li DMEM eklendi ve 24 saat sonra toksisitesi belirlendi. (BT-474 kullanıldı).', 'wst1-24h-03.03.16.xlsx', '1');
INSERT INTO `labs` VALUES ('78', '2016-03-30 00:00:00', 'WST1 HER2', 'MDA-MB-231 meme kanseri hücreleri 5.000 Cells/well olacak şekilde ekildi. 8ug ile 0,625 ug arasında HER2 morpholino embedded DNA origami ile treat edildi. 24 saat sonrasında wst1 sonuçları alındı. HER2 expresyonu olmayan bu hücre hattında DNA origamilerin toksik olmadıkları anlaşıldı.', '30,03,2016 MDA 24 H wst1.xlsx', '1');

-- ----------------------------
-- Table structure for lab_category
-- ----------------------------
DROP TABLE IF EXISTS `lab_category`;
CREATE TABLE `lab_category` (
  `cat_id` int(11) NOT NULL AUTO_INCREMENT,
  `cat_name` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`cat_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of lab_category
-- ----------------------------
INSERT INTO `lab_category` VALUES ('1', 'Propasal');
INSERT INTO `lab_category` VALUES ('2', 'Updates');

-- ----------------------------
-- Table structure for users
-- ----------------------------
DROP TABLE IF EXISTS `users`;
CREATE TABLE `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(255) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of users
-- ----------------------------
INSERT INTO `users` VALUES ('1', 'cansu', '123');
