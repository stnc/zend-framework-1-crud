/*
Navicat MySQL Data Transfer

Source Server         : lo
Source Server Version : 50505
Source Host           : 127.0.0.1:3306
Source Database       : guestbook

Target Server Type    : MYSQL
Target Server Version : 50505
File Encoding         : 65001

Date: 2017-05-05 15:28:21
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for guestbook
-- ----------------------------
DROP TABLE IF EXISTS `guestbook`;
CREATE TABLE `guestbook` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `email` varchar(255) DEFAULT NULL,
  `comment` text,
  `created` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

-- ----------------------------
-- Records of guestbook
-- ----------------------------
INSERT INTO `guestbook` VALUES ('1', 'ddd@dd.com', 'deneme', '2017-05-04 10:25:34');
INSERT INTO `guestbook` VALUES ('2', 'ddd444@dd3.com', 'deneme3  fd', '2017-05-04 10:25:54');
INSERT INTO `guestbook` VALUES ('3', 'dd@dd.com', 'fsdf', '2017-05-04 09:26:48');
